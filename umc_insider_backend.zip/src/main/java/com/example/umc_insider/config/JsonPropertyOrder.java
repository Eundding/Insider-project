package com.example.umc_insider.config;

public @interface JsonPropertyOrder {
}
