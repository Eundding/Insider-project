package com.example.umc_insider.utils;

public class Secret {
    public static String JWT_SECRET_KEY = "135b8378904571a649516713c9b3bbffc14f3464a3131504aec324cde5327b4d";
}