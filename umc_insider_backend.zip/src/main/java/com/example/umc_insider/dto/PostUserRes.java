package com.example.umc_insider.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
@Getter
public class PostUserRes {
    private Long id;
    private String nickname;
}
